from pathlib import Path
from ipseitas_pipeline import IpseitasGapLearner, MockLLM

norm = """
Understand why particles can behave like waves and how this relates to the double-slit experiment.
"""

learner = IpseitasGapLearner(provider=MockLLM())
learner.run(norm_of_study=norm, steps=3)

report = learner.report_markdown(norm)
print(report)

Path("sample_output.md").write_text(report, encoding="utf-8")
Path("sample_output.json").write_text(
    learner.self_model.to_json(),
    encoding="utf-8"
)

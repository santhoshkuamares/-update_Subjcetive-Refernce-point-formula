"""
Ipseitas Self-Directed Information-Gap Learner
---------------------------------------------

A small prototype of the user's theory:

SRP -> Information Gap -> Norm of Study -> Sub-goals -> Ipseitas / metacognitive check -> update.

This file runs WITHOUT an API key using MockLLM.
It also includes optional adapters for:
- Anthropic Claude
- Hugging Face Transformers

Important:
This is not evidence of consciousness. It is a functional prototype showing how a pretrained
model can be wrapped in a recursive information-gap learning loop.
"""

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional, Protocol
import json
import re
import textwrap
import os


# -----------------------------
# 1. LLM provider interface
# -----------------------------

class LLMProvider(Protocol):
    def generate(self, prompt: str, max_tokens: int = 700) -> str:
        ...


class MockLLM:
    """
    Offline deterministic mock provider.
    Use this to test the full pipeline without internet, API keys, or model downloads.
    Replace with AnthropicLLM or HuggingFaceLLM when you run it locally/Colab.
    """

    def generate(self, prompt: str, max_tokens: int = 700) -> str:
        p = prompt.lower()

        if "return only valid json" in p and "generate the next information gap" in p:
            norm = _extract_between(prompt, "NORM_OF_STUDY:", "SELF_MODEL:") or "the target problem"
            sm = _safe_json_from_between(prompt, "SELF_MODEL:", "Task:")
            n_questions = len(sm.get("questions_asked", [])) if isinstance(sm, dict) else 0

            if n_questions == 0:
                gap = "The learner has not yet identified the core mechanism behind the target phenomenon."
                subq = "What is the core mechanism that makes the target problem puzzling?"
                why = "A core mechanism can compress many smaller questions under one explanation."
            elif n_questions == 1:
                gap = "The learner has a provisional mechanism, but evidence grounding is still weak."
                subq = "What evidence would confirm or challenge the provisional explanation?"
                why = "This prevents false closure by checking whether coherence is supported by evidence."
            else:
                gap = "The learner still needs to compare alternatives and decide what remains unresolved."
                subq = "What alternative explanation could fit the same facts, and what would distinguish it?"
                why = "A competing explanation tests whether the current answer truly reduces the gap."

            return json.dumps({
                "information_gap": gap,
                "sub_question": subq,
                "why_it_matters": why,
                "expected_compression": "High if the answer connects several sub-gaps while preserving evidence sensitivity.",
                "estimated_relevance": 8,
                "estimated_solvability": 7,
                "estimated_compression": 8
            }, indent=2)

        if "return only valid json" in p and "answer the sub-question" in p:
            subq = _extract_between(prompt, "SUB_QUESTION:", "NORM_OF_STUDY:") or "the sub-question"

            if "core mechanism" in subq.lower():
                answer_text = (
                    "The core mechanism is that the system should not jump directly to a final answer. "
                    "It should identify what relation is missing, create a sub-goal around that missing relation, "
                    "and test whether resolving it reduces the larger Norm of Study. In the double-slit example, "
                    "the learner would first isolate the puzzle that one entity seems to produce an interference "
                    "pattern while still being detected as individual events."
                )
                remaining = "The answer needs evidence from quantum theory and experiment before the gap is closed."
                evidence = "Internal reasoning plus the structure of the double-slit problem."
            elif "evidence" in subq.lower():
                answer_text = (
                    "Confirming evidence would include whether the proposed mechanism explains both the interference "
                    "pattern and the particle-like detection events. Challenging evidence would be any case where the "
                    "same explanation fails to predict the pattern, the measurement effect, or the change in outcome "
                    "when which-path information is available."
                )
                remaining = "The learner still needs to compare this explanation with alternatives."
                evidence = "Evidence-checking logic, not external experimental data."
            else:
                answer_text = (
                    "An alternative explanation might describe the effect only as measurement disturbance or only as "
                    "statistical patterning. The distinguishing test is whether the explanation accounts for both the "
                    "wave-like interference structure and the discrete detection outcomes without ignoring either side."
                )
                remaining = "The remaining gap is which account gives the best evidence-sensitive compression."
                evidence = "Alternative-comparison logic."

            return json.dumps({
                "answer": answer_text,
                "confidence": 7,
                "remaining_uncertainty": remaining,
                "evidence_used": evidence,
                "possible_false_closure": "The learner may accept a neat explanation before checking whether it preserves all the relevant evidence."
            }, indent=2)

        if "return only valid json" in p and "metacognitive evaluation" in p:
            return json.dumps({
                "gap_reduction": 7,
                "coherence_gain": 8,
                "compression_potential": 7,
                "confidence_calibration": 6,
                "evidence_grounding": 4,
                "false_closure_risk": 5,
                "metacognitive_score": 5.9,
                "decision": "keep_and_branch",
                "reason": (
                    "The answer reduces uncertainty and improves coherence, but evidence grounding is low. "
                    "The next step should ask for external checks, counterexamples, or a more precise mechanism."
                )
            }, indent=2)

        if "return only valid json" in p and "update the self-model" in p:
            sm = _safe_json_from_between(prompt, "CURRENT_SELF_MODEL:", "GAP:")
            n_questions = len(sm.get("questions_asked", [])) if isinstance(sm, dict) else 0

            if n_questions == 0:
                known = [
                    "The learner has identified a provisional core mechanism.",
                    "The learner knows the answer must reduce the main Norm of Study, not just sound fluent."
                ]
                unknown = [
                    "Which evidence confirms or challenges the provisional mechanism?",
                    "Whether the explanation preserves all important parts of the problem."
                ]
                next_move = "Check evidence before accepting the mechanism."
            elif n_questions == 1:
                known = [
                    "The learner has identified evidence checks for the provisional mechanism.",
                    "The learner knows that false closure is a risk when coherence is high but evidence grounding is low."
                ]
                unknown = [
                    "Which alternative explanation can fit the same observations?",
                    "What would distinguish the current explanation from that alternative?"
                ]
                next_move = "Generate and compare an alternative explanation."
            else:
                known = [
                    "The learner has compared the current explanation with at least one alternative.",
                    "The learner has a clearer map of what remains unresolved."
                ]
                unknown = [
                    "Whether external empirical sources support the chosen explanation.",
                    "Whether the current explanation generalizes to related cases."
                ]
                next_move = "Seek external sources or stop if the assignment only needs a prototype demonstration."

            return json.dumps({
                "new_known": known,
                "still_unknown": unknown,
                "next_best_move": next_move
            }, indent=2)

        return "MockLLM did not recognize the prompt format."


class AnthropicLLM:
    """
    Optional Claude adapter.

    Install:
        pip install anthropic

    Set:
        export ANTHROPIC_API_KEY="your_key_here"

    Example:
        provider = AnthropicLLM(model="claude-3-5-haiku-latest")
    """

    def __init__(self, model: str = "claude-3-5-haiku-latest", api_key: Optional[str] = None):
        try:
            import anthropic
        except ImportError as exc:
            raise ImportError("Install anthropic first: pip install anthropic") from exc

        self.client = anthropic.Anthropic(api_key=api_key or os.getenv("ANTHROPIC_API_KEY"))
        self.model = model

    def generate(self, prompt: str, max_tokens: int = 700) -> str:
        msg = self.client.messages.create(
            model=self.model,
            max_tokens=max_tokens,
            messages=[{"role": "user", "content": prompt}],
        )
        # Anthropic content blocks usually expose .text
        return "".join(getattr(block, "text", str(block)) for block in msg.content)


class HuggingFaceLLM:
    """
    Optional Hugging Face Transformers adapter.

    Install:
        pip install transformers torch accelerate

    Example:
        provider = HuggingFaceLLM(model_name="Qwen/Qwen2.5-0.5B-Instruct")
    """

    def __init__(self, model_name: str = "Qwen/Qwen2.5-0.5B-Instruct"):
        try:
            from transformers import pipeline
        except ImportError as exc:
            raise ImportError("Install transformers first: pip install transformers torch accelerate") from exc

        self.pipe = pipeline(
            "text-generation",
            model=model_name,
            device_map="auto",
        )

    def generate(self, prompt: str, max_tokens: int = 700) -> str:
        out = self.pipe(
            prompt,
            max_new_tokens=max_tokens,
            do_sample=True,
            temperature=0.4,
            return_full_text=False,
        )
        return out[0]["generated_text"].strip()


# -----------------------------
# 2. Data structures
# -----------------------------

@dataclass
class SelfModel:
    known: List[str] = field(default_factory=list)
    unknown: List[str] = field(default_factory=list)
    questions_asked: List[str] = field(default_factory=list)
    answers: List[Dict[str, Any]] = field(default_factory=list)
    evaluations: List[Dict[str, Any]] = field(default_factory=list)
    updates: List[Dict[str, Any]] = field(default_factory=list)

    def to_json(self) -> str:
        return json.dumps(asdict(self), indent=2, ensure_ascii=False)


@dataclass
class StepResult:
    step: int
    gap: Dict[str, Any]
    answer: Dict[str, Any]
    evaluation: Dict[str, Any]
    self_update: Dict[str, Any]


# -----------------------------
# 3. Core Ipseitas pipeline
# -----------------------------

class IpseitasGapLearner:
    """
    Formal loop:

    Norm of Study
      -> generate information gap
      -> generate sub-question
      -> answer sub-question
      -> metacognitive evaluation
      -> update self-model
      -> next gap

    In the theory language:
    The self_model approximates the system's current SRP-relative knowledge state.
    The metacognitive evaluator approximates Ipseitas.
    """

    def __init__(self, provider: Optional[LLMProvider] = None):
        self.provider = provider or MockLLM()
        self.self_model = SelfModel()
        self.history: List[StepResult] = []

    def generate_gap(self, norm_of_study: str) -> Dict[str, Any]:
        prompt = f"""
GENERATE THE NEXT INFORMATION GAP.

NORM_OF_STUDY:
{norm_of_study}

SELF_MODEL:
{self.self_model.to_json()}

Task:
Generate one information gap and one sub-question that should reduce the main Norm of Study.
Do not ask a random question. Ask the question with the best expected relevance, solvability, and compression potential.

Return only valid JSON with these keys:
information_gap, sub_question, why_it_matters, expected_compression,
estimated_relevance, estimated_solvability, estimated_compression
"""
        return _parse_json(self.provider.generate(prompt))

    def answer_subquestion(self, norm_of_study: str, sub_question: str) -> Dict[str, Any]:
        prompt = f"""
ANSWER THE SUB-QUESTION.

SUB_QUESTION:
{sub_question}

NORM_OF_STUDY:
{norm_of_study}

SELF_MODEL:
{self.self_model.to_json()}

Task:
Answer the sub-question in a way that helps reduce the main information gap.
State uncertainty and possible false closure.

Return only valid JSON with these keys:
answer, confidence, remaining_uncertainty, evidence_used, possible_false_closure
"""
        return _parse_json(self.provider.generate(prompt))

    def evaluate(self, norm_of_study: str, gap: Dict[str, Any], answer: Dict[str, Any]) -> Dict[str, Any]:
        prompt = f"""
METACOGNITIVE EVALUATION.

NORM_OF_STUDY:
{norm_of_study}

GAP:
{json.dumps(gap, indent=2, ensure_ascii=False)}

ANSWER:
{json.dumps(answer, indent=2, ensure_ascii=False)}

Task:
Evaluate whether this sub-question and answer reduced the original information gap.

Score from 0 to 10:
- gap_reduction
- coherence_gain
- compression_potential
- confidence_calibration
- evidence_grounding
- false_closure_risk

Use this cost function:
metacognitive_score =
0.30*gap_reduction
+ 0.20*coherence_gain
+ 0.20*compression_potential
+ 0.15*confidence_calibration
+ 0.15*evidence_grounding
- 0.25*false_closure_risk

Return only valid JSON with these keys:
gap_reduction, coherence_gain, compression_potential, confidence_calibration,
evidence_grounding, false_closure_risk, metacognitive_score, decision, reason

Decision must be one of:
keep_and_branch, revise_question, seek_evidence, stop_gap_closed
"""
        raw = _parse_json(self.provider.generate(prompt))
        # Recalculate score ourselves so it is not only LLM self-report.
        raw["metacognitive_score"] = round(
            0.30 * float(raw.get("gap_reduction", 0))
            + 0.20 * float(raw.get("coherence_gain", 0))
            + 0.20 * float(raw.get("compression_potential", 0))
            + 0.15 * float(raw.get("confidence_calibration", 0))
            + 0.15 * float(raw.get("evidence_grounding", 0))
            - 0.25 * float(raw.get("false_closure_risk", 0)),
            2
        )
        return raw

    def update_self_model(self, norm_of_study: str, gap: Dict[str, Any], answer: Dict[str, Any], evaluation: Dict[str, Any]) -> Dict[str, Any]:
        prompt = f"""
UPDATE THE SELF-MODEL.

NORM_OF_STUDY:
{norm_of_study}

CURRENT_SELF_MODEL:
{self.self_model.to_json()}

GAP:
{json.dumps(gap, indent=2, ensure_ascii=False)}

ANSWER:
{json.dumps(answer, indent=2, ensure_ascii=False)}

EVALUATION:
{json.dumps(evaluation, indent=2, ensure_ascii=False)}

Task:
Update the learner's working self-model.
Do not claim certainty if evidence grounding is low.

Return only valid JSON with these keys:
new_known, still_unknown, next_best_move
"""
        update = _parse_json(self.provider.generate(prompt))

        self.self_model.questions_asked.append(gap.get("sub_question", ""))
        self.self_model.answers.append(answer)
        self.self_model.evaluations.append(evaluation)
        self.self_model.updates.append(update)

        for item in update.get("new_known", []):
            if item not in self.self_model.known:
                self.self_model.known.append(item)

        self.self_model.unknown = update.get("still_unknown", self.self_model.unknown)

        return update

    def run(self, norm_of_study: str, steps: int = 3) -> List[StepResult]:
        for step in range(1, steps + 1):
            gap = self.generate_gap(norm_of_study)
            answer = self.answer_subquestion(norm_of_study, gap.get("sub_question", ""))
            evaluation = self.evaluate(norm_of_study, gap, answer)
            update = self.update_self_model(norm_of_study, gap, answer, evaluation)

            result = StepResult(
                step=step,
                gap=gap,
                answer=answer,
                evaluation=evaluation,
                self_update=update,
            )
            self.history.append(result)

            if evaluation.get("decision") == "stop_gap_closed":
                break

        return self.history

    def report_markdown(self, norm_of_study: str) -> str:
        lines = []
        lines.append("# Ipseitas Gap Learner Demo Report")
        lines.append("")
        lines.append(f"**Norm of Study:** {norm_of_study.strip()}")
        lines.append("")
        for item in self.history:
            lines.append(f"## Step {item.step}")
            lines.append("")
            lines.append(f"**Information gap:** {item.gap.get('information_gap', '')}")
            lines.append("")
            lines.append(f"**Self-generated sub-question:** {item.gap.get('sub_question', '')}")
            lines.append("")
            lines.append(f"**Answer:** {item.answer.get('answer', '')}")
            lines.append("")
            lines.append("**Metacognitive evaluation:**")
            lines.append("")
            lines.append(f"- Gap reduction: {item.evaluation.get('gap_reduction')}/10")
            lines.append(f"- Coherence gain: {item.evaluation.get('coherence_gain')}/10")
            lines.append(f"- Compression potential: {item.evaluation.get('compression_potential')}/10")
            lines.append(f"- Confidence calibration: {item.evaluation.get('confidence_calibration')}/10")
            lines.append(f"- Evidence grounding: {item.evaluation.get('evidence_grounding')}/10")
            lines.append(f"- False closure risk: {item.evaluation.get('false_closure_risk')}/10")
            lines.append(f"- Metacognitive score: {item.evaluation.get('metacognitive_score')}")
            lines.append(f"- Decision: {item.evaluation.get('decision')}")
            lines.append("")
            lines.append(f"**Self-model update:** {item.self_update.get('next_best_move', '')}")
            lines.append("")
        lines.append("## Final Self-Model")
        lines.append("")
        lines.append("```json")
        lines.append(self.self_model.to_json())
        lines.append("```")
        return "\n".join(lines)


# -----------------------------
# 4. Helpers
# -----------------------------

def _parse_json(text: str) -> Dict[str, Any]:
    """
    Robust JSON parser for LLM outputs.
    If the model wraps JSON in prose or code fences, try to extract it.
    """
    text = text.strip()

    # Remove markdown fences if present
    text = re.sub(r"^```(?:json)?", "", text).strip()
    text = re.sub(r"```$", "", text).strip()

    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    # Try extracting first JSON object
    match = re.search(r"\{.*\}", text, flags=re.DOTALL)
    if match:
        try:
            return json.loads(match.group(0))
        except json.JSONDecodeError:
            pass

    # Last-resort fallback
    return {
        "raw_text": text,
        "parse_warning": "Model did not return valid JSON."
    }


def _extract_between(text: str, start: str, end: str) -> str:
    try:
        return text.split(start, 1)[1].split(end, 1)[0].strip()
    except Exception:
        return ""


def _safe_json_from_between(text: str, start: str, end: str) -> Dict[str, Any]:
    raw = _extract_between(text, start, end)
    try:
        return json.loads(raw)
    except Exception:
        return {}


if __name__ == "__main__":
    norm = "Understand why particles can behave like waves and how this relates to the double-slit experiment."
    learner = IpseitasGapLearner(provider=MockLLM())
    learner.run(norm, steps=3)
    print(learner.report_markdown(norm))

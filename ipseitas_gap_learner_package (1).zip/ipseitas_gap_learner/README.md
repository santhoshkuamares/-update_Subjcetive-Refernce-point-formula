# Ipseitas Self-Directed Information-Gap Learner

This is a prototype implementation of the framework:

**Subjective Reference Point -> Information Gap -> Norm of Study -> Sub-goals -> Ipseitas / Metacognitive Check -> Self-model update**

The goal is not to prove AI consciousness. The goal is to show that a pretrained model can be wrapped in a recursive architecture where it:

1. receives a complex **Norm of Study**
2. detects its own **information gap**
3. generates a useful **sub-question**
4. answers that sub-question
5. evaluates whether the answer reduced the main gap
6. updates its working **self-model**
7. repeats the loop

## Quick run without API keys

```bash
python demo_run.py
```

This uses `MockLLM`, so it runs offline.

## Use with Claude

Install:

```bash
pip install anthropic
```

Set your key:

```bash
export ANTHROPIC_API_KEY="your_key_here"
```

Modify `demo_run.py`:

```python
from ipseitas_pipeline import IpseitasGapLearner, AnthropicLLM

provider = AnthropicLLM(model="claude-3-5-haiku-latest")
learner = IpseitasGapLearner(provider=provider)
```

## Use with Hugging Face

Install:

```bash
pip install transformers torch accelerate
```

Modify `demo_run.py`:

```python
from ipseitas_pipeline import IpseitasGapLearner, HuggingFaceLLM

provider = HuggingFaceLLM(model_name="Qwen/Qwen2.5-0.5B-Instruct")
learner = IpseitasGapLearner(provider=provider)
```

## Metacognitive cost function

The prototype calculates:

```text
metacognitive_score =
0.30 * gap_reduction
+ 0.20 * coherence_gain
+ 0.20 * compression_potential
+ 0.15 * confidence_calibration
+ 0.15 * evidence_grounding
- 0.25 * false_closure_risk
```

This protects the system from false closure. A simple explanation is not enough. It must reduce the gap while preserving evidence sensitivity.
